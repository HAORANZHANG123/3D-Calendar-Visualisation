#pragma once

#include "ofMain.h"
#include "ofxImGui.h"
#include "BaseTheme.h"
#include <functional>
#include "ofxAssimpModelLoader.h"

using namespace glm;

//GUI Theme setting
class RedTheme : public ofxImGui::BaseTheme
{
public:
	void setup() override;
};

//max box used
#define MAXBOX 366
//max loaded model
#define MAXMODEL 18

//a cube is a DataBox
class DateBox
{
public:
	//the date data
	//see function:year,month,day
	int y0, y1, y2, y3;
	int m0, m1;
	int d0, d1;
	int weekday;

	//days after/before today
	int day_n;

	//the head of event list attach to this date.
	class Event* evt = nullptr;
	//get year
	int year() { return y0 * 1000 + y1 * 100 + y2 * 10 + y3; }
	//get month
	int month() { return m0 * 10 + m1; }
	//get day
	int day() { return d0 * 10 + d1; }
	//get the corresponding event list from global event map (using date)
	void get_event(std::map<int, class Event*>& evtmap);
	//get weekday from year month day
	static int get_weekday(int y, int m, int d)
	{
		//apply Kim larsen calculation formula
		if (m == 1 || m == 2)
		{
			m += 12;
			y--;
		}
		int w = (d + 2 * m + 3 * (m + 1) / 5 + y + y / 4 - y / 100 + y / 400) % 7;
		return w + 10;
	}

	//caculate date after days(day_n)
	void get_date()
	{
		int n = day_n;
		//get system time (with format)
		string time = ofGetTimestampString();

		char inbuf[32];
		memcpy(inbuf, time.c_str(), 24);
		inbuf[19] = '\0';
		inbuf[10] = ' ';
		inbuf[13] = ':';
		inbuf[16] = ':';
		struct tm tmin;
		struct tm* pTmIn = &tmin;
		struct tm tmout;
		struct tm* pTmOut = &tmout;


		int year, month, day, hour, minute, second;
		::sscanf(inbuf, "%d-%d-%d %d:%d:%d", &year, &month, &day, &hour, &minute, &second);
		pTmIn->tm_year = year - 1900;
		pTmIn->tm_mon = month - 1;
		pTmIn->tm_mday = day;
		pTmIn->tm_hour = hour;
		pTmIn->tm_min = minute;
		pTmIn->tm_sec = second;
		pTmIn->tm_isdst = -1;

		//pTmIn sceneds sence 1970.1.1-00:00:00
		time_t _tm = mktime(pTmIn);

		//add days(transform to seconds)
		_tm += n * 60 * 60 * 24;


		pTmOut = localtime(&_tm);


		char buf[32];
		memset(buf, 0, sizeof(buf));
		strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", pTmOut);
		::sscanf(buf, "%d-%d-%d %d:%d:%d", &year, &month, &day, &hour, &minute, &second);

		//get result
		weekday = get_weekday(year, month, day);
		y3 = year % 10;
		y2 = (year - y3) / 10 % 10;
		y0 = year / 1000;
		y1 = (year - y0 * 1000) / 100;
		m1 = month % 10;
		m0 = month / 10;
		d0 = day / 10;
		d1 = day % 10;
	}

	//models used in our scene
	static ofxAssimpModelLoader models[MAXMODEL];
	struct NumberModel
	{
		int num_id;
		vec3 rotate;
		vec3 scale;
		vec3 tranlate;

	};
	//empty constrctor
	DateBox()
	{

	}
#if 1
	//emit a ray test if the ray intersected with the databox's bounding box
	bool intersects(const vec3& dpos, const vec3& ddir, float& outt, const std::function<vec3(const vec3 & pos)>* mapping, float s) const
	{
		vec3 ptOnPlane;

		vec3 min;
		vec3 max;
		if (!mapping)
		{
			//use s to scale size
			min = pos - size * s * 0.5f;
			max = pos + size * s * 0.5f;
		}
		else
		{
			//use mapping to get the new position 
			min = (*mapping)(pos) - size * s * 0.5f;
			max = (*mapping)(pos) + size * s * 0.5f;
		}
		const vec3& origin = dpos;
		const vec3& dir = ddir;
		float t;
		if (dir.x != 0.f)
		{
			if (dir.x > 0) t = (min.x - origin.x) / dir.x;
			else t = (max.x - origin.x) / dir.x;

			if (t > 0.f)
			{
				ptOnPlane = origin + t * dir;
				if (min.y < ptOnPlane.y && ptOnPlane.y < max.y && min.z < ptOnPlane.z && ptOnPlane.z < max.z)
				{
					outt = t;
					return true;
				}
			}
		}
		if (dir.y != 0.f)
		{
			if (dir.y > 0)
				t = (min.y - origin.y) / dir.y;
			else
				t = (max.y - origin.y) / dir.y;

			if (t > 0.f)
			{
				ptOnPlane = origin + t * dir;

				if (min.z < ptOnPlane.z && ptOnPlane.z < max.z && min.x < ptOnPlane.x && ptOnPlane.x < max.x)
				{
					outt = t;
					return true;
				}
			}
		}

		if (dir.z != 0.f)
		{
			if (dir.z > 0)
				t = (min.z - origin.z) / dir.z;
			else
				t = (max.z - origin.z) / dir.z;

			if (t > 0.f)
			{
				ptOnPlane = origin + t * dir;

				if (min.x < ptOnPlane.x && ptOnPlane.x < max.x && min.y < ptOnPlane.y && ptOnPlane.y < max.y)
				{
					outt = t;

					return true;
				}
			}
		}

		return false;
	}
#endif
	//darw with proxy
	void draw_proxy(const std::function<vec3(const vec3 & pos)>& proxy_mappinng, float s = 1)
	{

		ofDrawBox(proxy_mappinng(pos), size.x * s, size.y * s, size.z * s);

	}
	//for test
	void draw_data(const std::function<vec3(const vec3 & pos)>& proxy_mappinng)
	{
		if (pos.z > -200 && pos.z < 200)
		{
			ofPushStyle();
			ofSetColor(ofColor::red);
			ofDrawBitmapString("2020.10.14", proxy_mappinng(pos) + vec3(0, size.y * 0.6f, 0));
			ofPopStyle();
		}
	}
	//for test
	void lerp_move_to(const vec3& target_pos)
	{
		if (lerp_pos)
		{
			auto d = (target_pos - pos);
			float norm = sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
			d /= norm;
			float dt = ofGetFrameRate();
			pos += d * dt;
			if (pos.z >= target_pos.z)
				lerp_pos = false;
		}
	}
	//center postion of the date box
	vec3 pos;
	//size of the box
	//see line 142 for more infomation
	vec3 size;
	//if the box has been selected
	bool checked = false;
	//moving?
	bool lerp_pos = false;
	//for list 
	//next node position
	int idx_next = -1;
	//previous node possition
	int idx_pre = -1;
};

class CalendarApplication : public ofBaseApp
{

public:
	~CalendarApplication();
	void setup();
	void update();
	void draw();
	void mousePressed(int x, int y, int button);
	float get_box_scale(float z);
	float get_event_model_scale(float z);

	//ofShader shader;
	//date box size
	vec3 bsize = vec3(50, 5, 10);
	//camera
	ofEasyCam easy_cam1;
	//light to light scene
	ofLight light;
	//material to controll the color of the model
	ofMaterial material;

	//ofTrueTypeFont font;
	DateBox date_box[MAXBOX];

	//cast ray from screen
	vec3 ray_pos;
	vec3 ray_dir;

	//slected box id in date_box
	int idx_checked = -1;
	//current moving box id in date box
	int idx_move = -1;
	int idx_tail = -1;
	int idx_head = -1;
	//move direction +1/-1
	float move_dir = 0;

	float cam_line_pos = 0;// easy_cam.getPosition().z;
	float front_dist = MAXBOX / 2 * 50;
	float behind_dist = MAXBOX / 2 * 50;
	float minz = cam_line_pos - front_dist;
	float maxz = cam_line_pos + behind_dist;

	float interval = 50;

	//vec2 proxy_position;
	float move_speed = 0.5;
	float move_speed_bk = 0.5;
	//mapping function
	std::function<vec3(const vec3 & pos)> proxy_mappinng_cos;
	//mapping parameter
	float mapping_cos_f = 0.f;
	float mapping_cos_a = 0.f;

	//bigger
	//-max_scale/scale_dist*x+max_scale=y
	float max_scale = 3;
	float scale_dist = 50 * 8;
	//scale event model
	float evt_fix_scale = 1.81f;
	float evt_scale_coff = 0.01f;


	//gui controll varible
	ofxImGui::Gui gui;
	bool useEasyCam = false;

	//store allocated events
	std::list<class Event*> allocated_events;
	//event map(key:date;val:event ptr)
	std::map<int, class Event*> date_events;
	//the only way to add an event
	class Event* add_event(int y, int m, int d, const string& notes,float* c);
	//remove all ecents related to a date
	void remove_event(int y, int m, int d);
	//remove specific event
	void remove_event(class Event* evt);

	//for event notes input
	char input_notes[2048];
	//right click mouse
	int right_checked_box_id = -1;
	int right_checked_x = -1;
	int right_checked_y = -1;
	//touch gui?
	//if do, mouse will not be avaliable
	bool gui_touch = false;

	//sleceted event tag color
	float col[3];
};

//event 
class Event
{
private:
	//dont allow create event out of CalendarApplication::add_event
	Event() { col[0] = 1; col[1] = 1; col[2] = 1; }
public:
	friend Event* CalendarApplication::add_event(int y, int m, int d, const string& notes,float*);
	//event date
	int year, month, day;
	//event tag color
	float col[3];
	//event notes
	std::string notes;
	//next event
	Event* next = nullptr;
};