#pragma once
#include "BaseTheme.h"

namespace ofxImGui
{
    class DefaultTheme: public ofxImGui::BaseTheme
    {
    public:
        
        void setup() override;
    };
}

