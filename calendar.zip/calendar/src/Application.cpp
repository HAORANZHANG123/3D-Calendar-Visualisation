#include "Application.h"

ofxAssimpModelLoader DateBox::models[MAXMODEL];

//is leap year?
int isLeap(int y)
{
	return y % 4 == 0 && y % 100 == 0 || y % 400 == 0;
}

//how many days of month
int daysOfMonth(int y, int m)
{
	int days[12] = { 31,0,31,30,31,30,31,31,30,31,30,31 };
	if (m != 2)
		return days[m - 1];
	else
		return 28 + isLeap(y);
}

//how many days in a year
int daysOfDate(int y, int m, int d)
{
	int days = 0;
	for (int y = 1; y <= y; y++)
		days += 365 + isLeap(y);
	for (int m1 = 1; m1 < m; m1++)
		days += daysOfMonth(y, m);
	days += d;
	return days;
}

//days between two date
int daysBetweenDates(int y, int m, int d, int y1, int m1, int d1)
{
	return abs(daysOfDate(y, m, d) - daysOfDate(y1, m1, d1));
}

//construct a id of a date
int getIDofDate(int y, int m, int d)
{
	return y * 10000 + m * 100 + d;
}

//extract date from an id
void getDateFromID(int id, int& y, int& m, int& d)
{
	d = id % 100;
	y = id / 10000;
	m = (id - y * 10000) / 100;
}

//dector
CalendarApplication::~CalendarApplication()
{
	//delete resources
	//...
}

//--------------------------------------------------------------
void CalendarApplication::setup()
{
	//load all models
	int midx = 0;
	DateBox::models[midx].loadModel("0.obj");
	midx++;
	DateBox::models[midx].loadModel("1.obj");
	midx++;
	DateBox::models[midx].loadModel("2.obj");
	midx++;
	DateBox::models[midx].loadModel("3.obj");
	midx++;
	DateBox::models[midx].loadModel("4.obj");
	midx++;
	DateBox::models[midx].loadModel("5.obj");
	midx++;
	DateBox::models[midx].loadModel("6.obj");
	midx++;
	DateBox::models[midx].loadModel("7.obj");
	midx++;
	DateBox::models[midx].loadModel("8.obj");
	midx++;
	DateBox::models[midx].loadModel("9.obj");
	midx++;
	DateBox::models[midx].loadModel("Mon.obj");
	midx++;
	DateBox::models[midx].loadModel("Tues.obj");
	midx++;
	DateBox::models[midx].loadModel("Wed.obj");
	midx++;
	DateBox::models[midx].loadModel("Thur.obj");
	midx++;
	DateBox::models[midx].loadModel("Fri.obj");
	midx++;
	DateBox::models[midx].loadModel("Sat.obj");
	midx++;
	DateBox::models[midx].loadModel("Sun.obj");
	midx++;
	DateBox::models[midx].loadModel("Event.obj");

	//init models
	for (int i = 0; i <= midx - 1; ++i)
	{
		DateBox::models[i].enableNormals();
		DateBox::models[i].setRotation(0, 90, 1, 0, 0);
		DateBox::models[i].setScale(0.03, 0.03, 0.03);
		//DateBox::models[i].setPosition(0, 2.5, -5);
	}

	//model.setScale(-1, 1, 1);

	//set up imgui
	gui.setup();
	ImGui::GetIO().MouseDrawCursor = false;

	//set VS
	ofSetVerticalSync(true);
	//set backgound color
	ofBackground(20);

	// GL_REPEAT for texture wrap only works with NON-ARB textures //
	ofDisableArbTex();
	ofSetSmoothLighting(true);
	//light.setAreaLight(10, 10);

	//set lighting color
	light.setDirectional();
	light.setDiffuseColor(ofFloatColor(.85 / 2, .85 / 2, .55 / 2));
	light.setSpecularColor(ofFloatColor(1.f, 1.f, 1.f));
	light.enable();
	// shininess is a value between 0 - 128, 128 being the most shiny //
	material.setShininess(120);
	// the light highlight of the material //
	material.setSpecularColor(ofColor(255, 255, 255, 255));

	//a function to map new postion of a box
	proxy_mappinng_cos = [&](const vec3& pos)->vec3
	{
		vec3 dpos = pos;
		dpos.x = mapping_cos_a * sin(mapping_cos_f * dpos.z);
		return dpos;
	};
	//init boxes
	for (int i = 0; i < MAXBOX; ++i)
	{
		date_box[i].idx_next = (i + 1) % MAXBOX;
		if (i - 1 > -1) date_box[i].idx_pre = i - 1;
		date_box[i].pos = glm::vec3(10, 5, maxz - i * interval);
		date_box[i].size = bsize;
	}
	//init date related to boxes
	date_box[0].idx_pre = MAXBOX - 1;
	idx_head = 0;
	idx_tail = MAXBOX - 1;
	int midi = 0;
	for (int i = 0; i < MAXBOX; ++i)
	{
		if (date_box[i].pos.z == 0)
		{
			midi = i;
			break;
		}
	}
	for (int i = 0; i < MAXBOX; ++i)
	{
		date_box[i].day_n = i - midi;
		date_box[i].get_date();
	}

	//init camera
	easy_cam1.setPosition(glm::vec3(-217.159439, 311.441742, 376.168549));
	//easy_cam1.setTarget(easy_cam1.getPosition() + glm::vec3(0.428398, -0.534998, -0.728184));
	easy_cam1.lookAt(easy_cam1.getPosition() + glm::vec3(0.428398, -0.534998, -0.728184));


}

//--------------------------------------------------------------
void CalendarApplication::update()
{
	//update imgui
	gui.begin();
}

//get the scale factor of a box
float CalendarApplication::get_box_scale(float z)
{
	float s = abs(z) * (1 - max_scale) / scale_dist + max_scale;
	s = s < 1 ? 1 : s;
	return s;
}

//get the scale factor of a model
float CalendarApplication::get_event_model_scale(float z)
{
	float s = 1.f + evt_scale_coff * abs(z);
	if (s > evt_fix_scale)
		s = evt_fix_scale;
	return s;
}

//add a event 
Event* CalendarApplication::add_event(int y, int m, int d, const string& notes, float* c)
{
	//allocate event
	auto* evt = new Event();
	evt->year = y; evt->month = m; evt->day = d;
	evt->notes = notes;
	evt->col[0] = c[0];
	evt->col[1] = c[1];
	evt->col[2] = c[2];

	//store
	allocated_events.push_back(evt);
	int id = getIDofDate(y, m, d);
	auto iter = date_events.find(id);
	if (iter != date_events.end() && iter->second)
	{
		//add to head
		evt->next = iter->second;
	}

	date_events[id] = evt;
	return evt;
}

//remove event by date
void CalendarApplication::remove_event(int y, int m, int d)
{
	Event* evt = nullptr;
	//get id by date
	int id = getIDofDate(y, m, d);
	auto iter = date_events.find(id);
	if (iter != date_events.end() && iter->second)
	{
		//travese list
		evt = iter->second;
		Event* p = evt;
		while (p)
		{
			allocated_events.remove(p);
			p = p->next;
		}
	}
	date_events.erase(iter);
	delete evt;
}

//remove event by event self
void CalendarApplication::remove_event(Event* evt)
{
	allocated_events.remove(evt);
	//get id by date
	int id = getIDofDate(evt->year, evt->month, evt->day);
	//find
	auto iter = date_events.find(id);
	if (iter != date_events.end() && iter->second)
	{
		//traverse list
		//find it and remove
		Event* p = iter->second;
		if (p == evt)
		{
			if (!p->next)
			{
				date_events.erase(iter);
			}
			else
			{
				date_events[id] = p->next;
			}
			return;
		}
		Event* p1 = p->next;
		while (p1)
		{
			if (p1 == evt)
			{
				//allocated_events.remove(p1);
				p->next = p1->next;
			}
			p = p->next;
			p1 = p1->next;
		}
	}
	delete evt;
}

//draw boxes
void CalendarApplication::draw()
{
	///////////////////////////////////////
	//handle GUI
	///////////////////////////////////////
	//allocated events window
	ImGui::Begin("allocated_events");
	//draw all events one by one
	for (auto* p : allocated_events)
	{
		ImGui::LabelText("Date", "%d.%d.%d", p->year, p->month, p->day);
		ImGui::SameLine();
		ImGui::ColorButton("", ImVec4(p->col[0], p->col[1], p->col[2], 1));
		ImGui::LabelText("Notes", "%s", p->notes.c_str());
		ImGui::Separator();
	}
	ImGui::End();
	//detect mouse gui touch
	gui_touch = false;
	//if mouse left clicked a box.
	//othewise, idx_checked=-1
	if (idx_checked >= 0)
	{
		//set window posrtion
		ImGui::SetWindowPos(ImVec2(0, 0));
		//draw events related to slected box
		ImGui::Begin("Events");
		ImGui::LabelText("Date", "%d.%d.%d", date_box[idx_checked].year(), date_box[idx_checked].month(), date_box[idx_checked].day());
		ImGui::Separator();
		//lazy get event
		if (!date_box[idx_checked].evt)
			date_box[idx_checked].get_event(date_events);
		auto* p = date_box[idx_checked].evt;
		int ne = 0;

		//used to format string
		char aa[16];
		memset(aa, 0, 16);

		//scan all events
		while (p)
		{
			ImGui::LabelText("", "Event %d", ne++);
			ImGui::SameLine();
			ImGui::ColorButton("", ImVec4(p->col[0], p->col[1], p->col[2], 1));
			ImGui::LabelText("Notes", "%s", p->notes.c_str());

			sprintf(aa, "Delete!###%d", ne);
			//if push button, delete this event
			if (ImGui::Button(aa))
			{
				remove_event(p);
				//may deleted the head of the list
				//restore
				date_box[idx_checked].get_event(date_events);
				break;
			}
			ImGui::Separator();

			p = p->next;
		}

		ImGui::End();
	}
	gui_touch |= ImGui::IsWindowHovered();
	ImGui::SetWindowPos(ImVec2(600, 0));
	if (right_checked_box_id >= 0)
	{
		//if mouse right clicked a box, popup "event add" window
		ImGui::OpenPopup("Need add Event?");

	}
	//popup window
	ImGui::SetNextWindowSize(ImVec2(200, 400));
	if (ImGui::BeginPopupModal("Need add Event?", NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove))
	{
		gui_touch |= true;
		if (ImGui::InputTextMultiline("Notes", input_notes, 2048, ImVec2(100, 100), ImGuiInputTextFlags_EnterReturnsTrue))
		{
			//pressed enter  when input notes
			goto end;
		}

		ImGui::ColorPicker3("Color tag", col);

		ImGui::Separator();

		ImGui::Separator();
		if (ImGui::Button("Yes", ImVec2(40, 20)))
		{
			//add event
		end:
			auto& b = date_box[right_checked_box_id];
			add_event(b.year(), b.month(), b.day(), input_notes, col);
			b.get_event(date_events);
			//clear input cache
			input_notes[0] = '\0';
			//cancle right checked label
			right_checked_box_id = -1;
			ImGui::CloseCurrentPopup();
		}
		ImGui::SameLine();

		if (ImGui::Button("No", ImVec2(40, 20)))
		{
			//cancled to add event
			//cancle right checked label
			right_checked_box_id = -1;
			ImGui::CloseCurrentPopup();
		}
		ImGui::EndPopup();
	}
	//draw float slider
	ImGui::SliderFloat("Cos mapping freqency", &mapping_cos_f, 0.0f, 0.03f);
	ImGui::SliderFloat("Cos mapping amplitude", &mapping_cos_a, 0.0f, 800.0f);
	//did mouse touch gui?
	gui_touch |= ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow);
	//draw checkbox
	ImGui::Checkbox("Use easy cam", &useEasyCam);
	//if you touched gui, you cannot handle camera
	if (!useEasyCam)
	{
		easy_cam1.disableMouseInput();
		easy_cam1.disableMouseMiddleButton();
	}
	else
	{
		easy_cam1.enableMouseInput();
		easy_cam1.enableMouseMiddleButton();
	}
	if (gui_touch)
	{
		easy_cam1.disableMouseInput();
		easy_cam1.disableMouseMiddleButton();
	}
	else
	{
		easy_cam1.enableMouseInput();
		easy_cam1.enableMouseMiddleButton();
		if (!useEasyCam)
		{
			easy_cam1.disableMouseInput();
			easy_cam1.disableMouseMiddleButton();
		}
	}

	//set light
	light.setOrientation(glm::vec3(45, 45, -45));
	ofEasyCam& easy_cam = easy_cam1;
	easy_cam.begin();
	//opengl related
	ofEnableDepthTest();
	ofEnableLighting();

	//whether animate
	float dt = ofGetFrameRate();
	//moving?
	if (idx_move >= 0)
	{

#if 0
		if (date_box[idx_move].pos.z * move_dir >= 0)
		{
			//fix position
			move_dir = 0;
			idx_move = -1;
		}


		if (date_box[idx_move].pos.z == 0)
			move_dir = 0;
#else
		//if sleceted box move to postion which z is nearly 0
		if (abs(date_box[idx_move].pos.z) < 0.001)
		{
			move_dir = 0;
			idx_move = -1;
		}
		//change move speed
		if (abs(date_box[idx_move].pos.z) < dt * move_speed)
			move_speed = abs(date_box[idx_move].pos.z / dt);

#endif
		//move all boxes
		for (int i = 0; i < MAXBOX; ++i)
		{
			auto& dateb = date_box[i];
			//translate
			dateb.pos.z += dt * move_dir * move_speed;
		}
		for (int i = 0; i < MAXBOX; ++i)
		{
			auto& dateb = date_box[i];
			if (move_dir > 0)
			{
				//if the box move out of spercific distance
				//move head to tail
				if (dateb.pos.z > maxz)
				{
					//change date
					dateb.day_n = date_box[idx_tail].day_n + 1;
					dateb.get_date();
					dateb.evt = nullptr;
					dateb.pos.z = date_box[idx_tail].pos.z - interval;
					idx_tail = i;
				}
			}
			if (move_dir < 0)
			{
				////if the box move out of spercific distance
				//move tail to head
				if (dateb.pos.z < minz)
				{
					//change date
					dateb.day_n = date_box[idx_head].day_n - 1;
					dateb.get_date();
					dateb.evt = nullptr;
					dateb.pos.z = date_box[idx_head].pos.z + interval;
					idx_head = i;
				}
			}
		}
		//search new head or tail
		//note any list based method and mathmatic based method is not easier than linear search
		//note:there may not be only 1 box out of the range
		if (move_dir > 0)
		{
			float temp_maxz = -99999999;
			int temp_maxid = -1;
			for (int i = 0; i < MAXBOX; ++i)
			{
				//find max z
				auto& dateb = date_box[i];
				if (dateb.pos.z > temp_maxz)
				{
					temp_maxz = dateb.pos.z;
					temp_maxid = i;
				}
			}
			idx_head = temp_maxid;
		}

		if (move_dir < 0)
		{
			float temp_minz = 99999999;
			int temp_minid = -1;
			for (int i = 0; i < MAXBOX; ++i)
			{
				//find min z
				auto& dateb = date_box[i];
				if (dateb.pos.z < temp_minz)
				{
					temp_minz = dateb.pos.z;
					temp_minid = i;
				}
			}
			idx_tail = temp_minid;
		}

	}
	//draw all the boxes
	for (int i = 0; i < MAXBOX; ++i)
	{
		auto& dateb = date_box[i];
		//get  view position
		auto position = dateb.pos;
		vec4 position_aff = vec4(position, 1);
		float fc = easy_cam.getFarClip();
		auto mv = easy_cam.getModelViewMatrix();
		auto positionv = mv * position_aff;

		//render box
		//is view postion.z>8000, we  dont draw it for performance
		if (abs(positionv.z) < 8000)
		{
			if (date_box[i].checked)
			{
				//if checked this frame 
				//draw it with red color
				ofPushStyle();
				ofSetColor(ofColor::red);
				float s = get_box_scale(date_box[i].pos.z);
				date_box[i].draw_proxy(proxy_mappinng_cos, s);
				ofPopStyle();
			}
			else
			{
				ofPushStyle();
				if (idx_head == i) ofSetColor(ofColor::blue);
				if (idx_tail == i)  ofSetColor(ofColor::red);
				vec3 dpos = date_box[i].pos;
				//get scale factor which used to make boxes bigger when closer
				float s = get_box_scale(date_box[i].pos.z);
				date_box[i].draw_proxy(proxy_mappinng_cos, s);


				float s0 = get_box_scale(0);
				float factor = s / s0;
				auto newp = proxy_mappinng_cos(date_box[i].pos);
				vec3 base_pos = newp - date_box[i].size * s * 0.5f;
				vec3 cpos = base_pos + vec3(10 * factor, date_box[i].size.y * s + 0.5, date_box[i].size.z * s / 3);
				vec3 oscale(0.01, 0.01, 0.01);

				auto os = oscale * factor;

				//transform all the models to right position
				//and draw them
				if (newp.z<1500 && newp.z>-1500)
				{
					//get models
					auto& mdy0 = DateBox::models[date_box[i].y0];
					auto& mdy1 = DateBox::models[date_box[i].y1];
					auto& mdy2 = DateBox::models[date_box[i].y2];
					auto& mdy3 = DateBox::models[date_box[i].y3];
					auto& mdm0 = DateBox::models[date_box[i].m0];
					auto& mdm1 = DateBox::models[date_box[i].m1];
					auto& mdd0 = DateBox::models[date_box[i].d0];
					auto& mdd1 = DateBox::models[date_box[i].d1];
					auto& mdw = DateBox::models[date_box[i].weekday];

					//year
					mdy0.setScale(os.x, os.y, os.z);
					mdy0.setPosition(cpos.x, cpos.y, cpos.z);
					mdy0.drawFaces();

					cpos = cpos + vec3(10, 0, 0) * factor;

					os = oscale * factor;
					mdy1.setScale(os.x, os.y, os.z);
					mdy1.setPosition(cpos.x, cpos.y, cpos.z);
					mdy1.drawFaces();

					cpos = cpos + vec3(10, 0, 0) * factor;

					os = oscale * factor;
					mdy2.setScale(os.x, os.y, os.z);
					mdy2.setPosition(cpos.x, cpos.y, cpos.z);
					mdy2.drawFaces();

					cpos = cpos + vec3(10, 0, 0) * factor;

					os = oscale * factor;
					mdy3.setScale(os.x, os.y, os.z);
					mdy3.setPosition(cpos.x, cpos.y, cpos.z);
					mdy3.drawFaces();

					//month
					oscale = vec3(0.028);
					vec3 mpos = base_pos + vec3(10 * factor, date_box[i].size.y * s + 0.5, date_box[i].size.z * s * 9.5f / 10);;
					mpos = mpos + vec3(20, 0, 0) * factor;
					os = oscale * factor;
					mdm0.setScale(os.x, os.y, os.z);
					mdm0.setPosition(mpos.x, mpos.y, mpos.z);
					mdm0.drawFaces();

					mpos = mpos + vec3(10, 0, 0) * factor;
					os = oscale * factor;
					mdm1.setScale(os.x, os.y, os.z);
					mdm1.setPosition(mpos.x, mpos.y, mpos.z);
					mdm1.drawFaces();

					//day
					oscale = vec3(0.045);
					vec3 dpos = base_pos + vec3(10 * factor, date_box[i].size.y * s + 0.5, date_box[i].size.z * s * 9.5f / 10);;
					dpos = dpos + vec3(45, 0, 0) * factor;
					os = oscale * factor;
					mdd0.setScale(os.x, os.y, os.z);
					mdd0.setPosition(dpos.x, dpos.y, dpos.z);
					mdd0.drawFaces();

					dpos = dpos + vec3(15, 0, 0) * factor;
					os = oscale * factor;
					mdd1.setScale(os.x, os.y, os.z);
					mdd1.setPosition(dpos.x, dpos.y, dpos.z);
					mdd1.drawFaces();

					//weekday
					oscale = vec3(0.025);
					vec3 wpos = base_pos + vec3(10 * factor, date_box[i].size.y * s + 0.5, date_box[i].size.z * s * 9.f / 10);;
					wpos = wpos + vec3(5, 0, 0) * factor;
					os = oscale * factor;
					mdw.setScale(os.x, os.y, os.z);
					mdw.setPosition(wpos.x, wpos.y, wpos.z);
					mdw.drawFaces();


				}

				ofPushStyle();
				ofSetColor(ofColor::red);

				//events
				//lazy get event
				if (!date_box[i].evt)
					date_box[i].get_event(date_events);
				if (date_box[i].evt)
				{
					//draw all the event tags one by one
					auto& mdn = DateBox::models[MAXMODEL - 1];
					oscale = vec3(0.05);
					os = oscale * factor;
					vec3 npos = base_pos + vec3(10 * factor, date_box[i].size.y * s + 0.5, date_box[i].size.z * s * 9.f / 10);;
					const auto* p = date_box[i].evt;
					int ne = 0;
					while (p)
					{
						int nx = ne % 4;
						int nz = ne / 4;
						auto ppos = npos + vec3(80 + nx * 16, 0, -nz * 16) * factor;
						if (ne < 7) ne++;
						float s = get_event_model_scale(date_box[i].pos.z);
						mdn.setScale(os.x * s, os.y * s, os.z * s);
						mdn.setPosition(ppos.x, ppos.y, ppos.z);
						mdn.getMeshHelper(0).material.setDiffuseColor(ofFloatColor(p->col[0], p->col[1], p->col[2]));
						mdn.getMeshHelper(0).material.setEmissiveColor(ofFloatColor(p->col[0], p->col[1], p->col[2]));
						mdn.drawFaces();

						p = p->next;
					}
				}

				ofPopStyle();
				ofPopStyle();
			}
		}
	}

	float minzpos = 0;
	static float z = 5.0;
	static float sz = 3.4;
	static float sin_speed = 0.03;
	static float sin_max = 0.25;

	ImGui::DragFloat("sz", &sin_speed, 0.0001, 0, 1);
	ImGui::DragFloat("szm", &sin_max, 0.1, 0.1, 1);

	//draw center frame box
	ofPushStyle();

	ofSetColor(ofColor::blue);
	ofSetLineWidth(2);
	ofNoFill();
	//cout << sin_max * (sin(ofGetFrameNum() * sin_speed) + 1) << endl;
	material.setEmissiveColor(ofFloatColor(
		sin_max * (sin(ofGetFrameNum() * sin_speed)) + 0.75f
	));
	material.begin();


	glm::vec3 sbsize = bsize * sz;
	ofDrawBox(glm::vec3(0, z, 0), sbsize.x, sbsize.y * 1.5, sbsize.z);
	material.end();
	ofDisableLighting();
	ofSetColor(ofFloatColor::red);
	ofFill();
	ofDrawArrow(glm::vec3(-140, 0, minzpos), glm::vec3(-90, 0, minzpos), 8);
	ofPopStyle();

	easy_cam.end();

	ofDisableDepthTest();

	//uncheck select tag
	if (idx_checked >= 0)
	{
		date_box[idx_checked].checked = false;
	}
	if (right_checked_box_id >= 0)
	{
		date_box[right_checked_box_id].checked = false;
	}
	gui.end();
}

//--------------------------------------------------------------
void CalendarApplication::mousePressed(int x, int y, int button)
{
	if (gui_touch)
		return;
	ofEasyCam& easy_cam = easy_cam1;

	if (button == 0)
	{
		auto c = easy_cam.screenToWorld(vec3(x, y, 0));
		ray_pos = easy_cam.getPosition();
		ray_dir = c - ray_pos;
		float t = 9999999;
		int idx = -1;
		for (int i = 0; i < MAXBOX; ++i)
		{
			float _t;
			float s = get_box_scale(date_box[i].pos.z);

			if (date_box[i].intersects(ray_pos, ray_dir, _t, &proxy_mappinng_cos, s) && _t < t)
			{
				t = _t;
				idx = i;
			}
		}
		if (idx >= 0)
		{
			date_box[idx].checked = true;
			idx_checked = idx;
			//prepare to move
			if (abs(date_box[idx_checked].pos.z) >= ofGetFrameRate() / 2)
			{
				move_speed = move_speed_bk;
				idx_move = idx;
				move_dir = date_box[idx_move].pos.z > 0 ? -1.f : 1.f;
			}
		}
	}
	if (button == 2)
	{
		auto c = easy_cam.screenToWorld(vec3(x, y, 0));
		ray_pos = easy_cam.getPosition();
		ray_dir = c - ray_pos;
		float t = 9999999;
		int idx = -1;
		for (int i = 0; i < MAXBOX; ++i)
		{
			float _t;
			float s = get_box_scale(date_box[i].pos.z);

			if (date_box[i].intersects(ray_pos, ray_dir, _t, &proxy_mappinng_cos, s) && _t < t)
			{
				t = _t;
				idx = i;
			}
		}
		if (idx >= 0)
		{
			date_box[idx].checked = true;
			right_checked_box_id = idx;
			right_checked_x = x;
			right_checked_y = y;

		}
	}



}

//find event by date
void DateBox::get_event(std::map<int, Event*>& evtmap)
{
	int id = getIDofDate(year(), month(), day());
	auto iter = evtmap.find(id);
	if (iter != evtmap.end() && iter->second)
	{
		evt = iter->second;
	}
	else
		evt = nullptr;

}