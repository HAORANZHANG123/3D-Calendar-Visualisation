#include "ofMain.h"
#include "Application.h"

int main(int c,const char** v )
{
	ofSetupOpenGL(1024,768,OF_WINDOW);
	ofRunApp(new CalendarApplication());
}